# Changelog / 更新记录

## 0.0.1 — development / 开发版

- Added explicitly selected volumes across folders/drives to inspect/verify/merge/ReShard, with per-source checks, chosen output, restart/recovery and no implicit completion of missing inputs.
- Added a cumulative desktop file list, read-only pre-output checks, path-entry alternative and traditional 2010s-style tabs, panels and buttons in both languages.
- Added source-only GitHub packaging and public-release guidance; retained the publisher-confirmed MIT license.

新增跨目录/U 盘分卷列表及检查、指定输出、继续任务支持；界面改为传统桌面风格；提供排除开发工具/缓存的纯源码包与 GitHub 发布说明。实体 U 盘/OS 拖放测试范围另行记录。

- User-selected name: 便捷压缩助手_V0.0.1 / Easy Archive Assistant. ArchiveFlow remains only in historical specifications.
- Raw ZIP/7z splitting, merging, balanced size planning, exact SHA-256 manifests, direct ReShard, single-part rebuilding, coverage diagnostics, and verified cross-set rescue.
- Exclusive output creation, bounded streaming, cancellation, full staging verification, recoverable publication, explicit recovery/restart, and Windows-owned staging-link cleanup.
- Chinese/English Tauri desktop with file selection/drop, plan review, exact u64 offsets, phase progress, cancellation, and scoped integrity results; independent bilingual CLI and JSON automation.
- Windows portable packaging, checksums, restricted desktop capabilities, CI definitions, and bilingual user/developer guidance.

新增原始分卷处理、直接重分卷、单卷重建、覆盖地图、完整来源跨组救援、可靠提交/恢复，以及独立中英双语 CLI 和桌面。具体执行证据和未验证范围见 IMPLEMENTATION_STATUS.md；此记录不等于公开发布、签名或全部平台验收。
